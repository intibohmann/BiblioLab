<?php

define('USUARIO', 'root');//usuario de conexao com o banco
define('SENHA','');//senha de conexao com o banco
define('HOST','localhost');//
define('PORT','3306');
define('DB','biblioteca');
define('DSN',"mysql:host=".HOST.";port=".PORT.";dbname=".DB.";charset=UTF8");

?>