<?php

define('USUARIO', 'root'); /// usuario de conexão com o banco
define('SENHA', ''); // senha de conexão com o banco
define('HOST', 'localhost'); // ip do servidor do banco
define('PORT', '3306'); // porta do mysql
define('DB', 'biblioteca'); // nome do banco
define('DSN', "mysql:host=".HOST.";port=".PORT.";dbname=".DB.";charset=UTF8");

?>